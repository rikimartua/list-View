package com.example.submissionsatu;

import android.os.Parcel;
import android.os.Parcelable;

public class film implements Parcelable {

    private int photo;
    private String judul;
    private String description;
    private String tahun;
    private String star;
    private String view;
    private String kategori;
    private String Genre;
    private String Duration;

    public  film(){

    }

    public film(int photo, String judul, String description, String tahun, String star, String view, String kategori, String genre, String duration) {
        this.photo = photo;
        this.judul = judul;
        this.description = description;
        this.tahun = tahun;
        this.star = star;
        this.view = view;
        this.kategori = kategori;
        Genre = genre;
        Duration = duration;
    }

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTahun() {
        return tahun;
    }

    public void setTahun(String tahun) {
        this.tahun = tahun;
    }

    public String getStar() {
        return star;
    }

    public void setStar(String star) {
        this.star = star;
    }

    public String getView() {
        return view;
    }

    public void setView(String view) {
        this.view = view;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public String getGenre() {
        return Genre;
    }

    public void setGenre(String genre) {
        Genre = genre;
    }

    public String getDuration() {
        return Duration;
    }

    public void setDuration(String duration) {
        Duration = duration;
    }

    protected film(Parcel in) {
        photo = in.readInt();
        judul = in.readString();
        description = in.readString();
        tahun = in.readString();
        star = in.readString();
        view = in.readString();
        kategori = in.readString();
        Genre = in.readString();
        Duration = in.readString();
    }

    public static final Creator<film> CREATOR = new Creator<film>() {
        @Override
        public film createFromParcel(Parcel in) {
            return new film(in);
        }

        @Override
        public film[] newArray(int size) {
            return new film[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(photo);
        dest.writeString(judul);
        dest.writeString(description);
        dest.writeString(tahun);
        dest.writeString(star);
        dest.writeString(view);
        dest.writeString(kategori);
        dest.writeString(Genre);
        dest.writeString(Duration);
    }

}
