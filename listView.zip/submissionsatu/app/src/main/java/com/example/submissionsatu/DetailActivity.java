package com.example.submissionsatu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;

public class DetailActivity extends AppCompatActivity {

    public static final String EXTRA_FILIM ="extra_film";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Toolbar toolbar= findViewById(R.id.toolbarDetail);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Film");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        ImageView img_detail = findViewById(R.id.img_detail);
        TextView tv_judul = findViewById(R.id.tv_detailJudul);
        TextView tv_description = findViewById(R.id.tv_detailDescription);
        TextView tv_tahun=findViewById(R.id.tv_detailTahun);
        TextView tv_bintang=findViewById(R.id.star);
        TextView tv_view=findViewById(R.id.viewer);
        TextView tv_genre=findViewById(R.id.genre);
        TextView tv_kategori=findViewById(R.id.kategori);
        TextView tv_duration=findViewById(R.id.duration);


        film film = getIntent().getParcelableExtra(EXTRA_FILIM);
        String judul= film.getJudul();
        String desc=film.getDescription();
        int image= film.getPhoto();
        String tahun = film.getTahun();
        String bintang=film.getStar();
        String view=film.getView();
        String genre=film.getGenre();
        String kategori=film.getKategori();
        String duratuion=film.getDuration();

        tv_judul.setText(judul);
        tv_description.setText(desc);
        img_detail.setImageResource(image);
        tv_tahun.setText(tahun);
        tv_bintang.setText(bintang);
        tv_view.setText(view);
        tv_genre.setText(genre);
        tv_kategori.setText(kategori);
        tv_duration.setText(duratuion);    }


}
