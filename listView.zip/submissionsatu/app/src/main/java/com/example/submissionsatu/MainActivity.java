package com.example.submissionsatu;

import android.content.Intent;
import android.content.res.TypedArray;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private FilmaAdapter adapter;
    private String[] dataJudul;
    private String[] dataDescription;
    private String[] dataTahun;
    private String[] dataStar;
    private String[] dataView;
    private String[] dataGenre;
    private String[] dataKategori;
    private String[] dataDuration;
    private TypedArray dataPhoto;
    private ArrayList<film> films;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



       ListView listView = findViewById(R.id.lv_list);
       adapter=new FilmaAdapter(this);
       listView.setAdapter(adapter);

        prepare();
        addItem();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                film film= new film();
                film.setPhoto(dataPhoto.getResourceId(position,0));
                film.setJudul(dataJudul[position]);
                film.setDescription(dataDescription[position]);
                film.setTahun(dataTahun[position]);
                film.setStar(dataStar[position]);
                film.setView(dataView[position]);
                film.setGenre(dataGenre[position]);
                film.setKategori(dataKategori[position]);
                film.setDuration(dataDuration[position]);
                Intent sendData = new Intent(MainActivity.this,DetailActivity.class);
                sendData.putExtra(DetailActivity.EXTRA_FILIM,film);
                startActivity(sendData);

            }
        });


    }
    private void prepare() {

        dataJudul= getResources().getStringArray(R.array.judul);
        dataDescription=getResources().getStringArray(R.array.description);
        dataPhoto=getResources().obtainTypedArray(R.array.data_photo);
        dataTahun=getResources().getStringArray(R.array.tahun);
        dataStar=getResources().getStringArray(R.array.bintang);
        dataView=getResources().getStringArray(R.array.viewer);
        dataGenre=getResources().getStringArray(R.array.genre);
        dataKategori=getResources().getStringArray(R.array.kategori);
        dataDuration=getResources().getStringArray(R.array.durasi);
    }

    private void addItem() {
        films = new ArrayList<>();

        for (int i=0;i<dataJudul.length;i++){
            film film = new film();
            film.setPhoto(dataPhoto.getResourceId(i,-1));
            film.setJudul(dataJudul[i]);
            film.setDescription(dataDescription[i]);
            film.setTahun(dataTahun[i]);
            film.setTahun(dataStar[i]);
            film.setTahun(dataView[i]);
            film.setTahun(dataGenre[i]);
            film.setTahun(dataKategori[i]);
            film.setTahun(dataDuration[i]);
            films.add(film);

        }
        adapter.setFilms(films);
    }



}
