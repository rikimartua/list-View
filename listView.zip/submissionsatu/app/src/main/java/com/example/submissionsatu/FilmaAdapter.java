package com.example.submissionsatu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class FilmaAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<film> films = new ArrayList<>();

    public FilmaAdapter(Context context) {
        this.context=context;

    }

    //seter hasil generet

    public void setFilms(ArrayList<film> films) {
        this.films = films;
    }


    @Override
    public int getCount() {
        return films.size();
    }

    @Override
    public Object getItem(int position) {
        return films.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View itemView = convertView;
        if (itemView==null){
            itemView= LayoutInflater.from(context).inflate(R.layout.item_film,parent,false);
        }

        ViewHolder viewHolder = new ViewHolder(itemView);

       film film =(film) getItem(position);
       viewHolder.bind(film);
        return itemView;
    }
    public class ViewHolder{

        private TextView txtjudul;
        private TextView txtDescription;
        private ImageView imgphoto;

        ViewHolder(View view){
            txtjudul = view.findViewById(R.id.txt_judul);
            txtDescription = view.findViewById(R.id.txt_description);
            imgphoto = view.findViewById(R.id.img_photo);
        }
        void bind(film film){
            txtjudul.setText(film.getJudul());
            txtDescription.setText(film.getDescription());
            imgphoto.setImageResource(film.getPhoto());
        }
    }
}
